package org.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/SOSServlet")
@MultipartConfig
public class SOSServlet extends HttpServlet {

    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws IOException, ServletException {

        try {

            HttpSession session =
                    request.getSession(false);

            if (session == null) {

                response.getWriter()
                        .print("NO SESSION");

                return;
            }

            String email =
                    (String) session
                            .getAttribute("email");

            String location =
                    request.getParameter(
                            "location");

            Part audioPart =
                    request.getPart("audio");

            InputStream audioStream =
                    null;

            if (audioPart != null) {

                audioStream =
                        audioPart.getInputStream();
            }

            Connection con =
                    DBConnection.getConnection();

            String sql =
                    "INSERT INTO sos_history " +
                            "(user_email, location, audio_file) " +
                            "VALUES (?, ?, ?)";

            PreparedStatement ps =
                    con.prepareStatement(sql);

            ps.setString(
                    1,
                    email
            );

            ps.setString(
                    2,
                    location
            );

            if(audioStream != null){

                ps.setBlob(
                        3,
                        audioStream
                );

            }else{

                ps.setNull(
                        3,
                        java.sql.Types.BLOB
                );
            }

            ps.executeUpdate();

            ps.close();
            con.close();

            response.getWriter()
                    .print(
                            "SOS SAVED"
                    );

        }
        catch (Exception e) {

            e.printStackTrace();

            response.getWriter()
                    .print(
                            "ERROR"
                    );
        }
    }
}