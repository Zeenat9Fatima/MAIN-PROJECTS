package org.example;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/TrustedContactServlet")
public class TrustedContactServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null){

            response.sendRedirect("signin.html");
            return;
        }


        String email =
                (String) session.getAttribute("email");
        String parentName =
                request.getParameter("parentName");

        String parentPhone =
                request.getParameter("parentPhone");

        String siblingName =
                request.getParameter("siblingName");

        String siblingPhone =
                request.getParameter("siblingPhone");

        String friendName =
                request.getParameter("friendName");

        String friendPhone =
                request.getParameter("friendPhone");

        if(!parentPhone.matches("[6-9]\\d{9}") ||
                !siblingPhone.matches("[6-9]\\d{9}") ||
                !friendPhone.matches("[6-9]\\d{9}")) {

            response.getWriter().println(
                    "Enter a valid 10-digit mobile number."
            );

            return;
        }
        try{

            Connection con =
                    DBConnection.getConnection();

            String query =
                    "INSERT INTO trusted_contacts(user_email,parent_name,parent_phone,sibling_name,sibling_phone,friend_name,friend_phone) VALUES(?,?,?,?,?,?,?)";

            PreparedStatement pst =
                    con.prepareStatement(query);

            pst.setString(1,email);
            pst.setString(2,parentName);
            pst.setString(3,parentPhone);
            pst.setString(4,siblingName);
            pst.setString(5,siblingPhone);
            pst.setString(6,friendName);
            pst.setString(7,friendPhone);

            pst.executeUpdate();

            response.sendRedirect("index.html");

        }catch(Exception e){

            e.printStackTrace();
        }
    }
}