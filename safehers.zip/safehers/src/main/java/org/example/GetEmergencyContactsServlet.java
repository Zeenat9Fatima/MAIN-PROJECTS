package org.example;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/GetEmergencyContactsServlet")
public class GetEmergencyContactsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws IOException {

        HttpSession session =
                request.getSession(false);

        if(session == null){

            response.getWriter().print("{}");
            return;
        }

        String email =
                (String) session.getAttribute("email");

        try{

            Connection con =
                    DBConnection.getConnection();

            String query =

                    "SELECT parent_phone," +
                            "sibling_phone," +
                            "friend_phone " +
                            "FROM trusted_contacts " +
                            "WHERE user_email=?";

            PreparedStatement pst =
                    con.prepareStatement(query);

            pst.setString(1,email);

            ResultSet rs =
                    pst.executeQuery();

            response.setContentType(
                    "application/json"
            );

            if(rs.next()){

                String json =

                        "{"

                                + "\"parent\":\""
                                + rs.getString("parent_phone")
                                + "\","

                                + "\"sibling\":\""
                                + rs.getString("sibling_phone")
                                + "\","

                                + "\"friend\":\""
                                + rs.getString("friend_phone")
                                + "\""

                                + "}";

                response.getWriter().print(json);

            }else{

                response.getWriter().print("{}");

            }

        }catch(Exception e){

            e.printStackTrace();

            response.getWriter().print("{}");

        }

    }
}