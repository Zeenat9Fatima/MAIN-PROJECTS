package org.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session =
                request.getSession(false);

        response.setContentType("text/html");

        if(session != null &&
                session.getAttribute("user") != null){

            String user =
                    (String) session.getAttribute("user");

            response.getWriter().println(

                    "<h1>Welcome " + user + " 👤</h1>"
            );

        } else {

            response.sendRedirect("signin.html");
        }
    }
}