
package org.example;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.Part;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/ComplaintServlet")
@MultipartConfig
public class ComplaintServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String complaint =
                request.getParameter("complaint");

        String location =
                request.getParameter("location");
        Part filePart =
                request.getPart("evidence");

        String fileName =
                filePart.getSubmittedFileName();
        HttpSession session =
                request.getSession();

        String user =
                request.getParameter("email");
        System.out.println("USER = " + user);
        System.out.println("LOCATION = " + location);
        try {

            Connection con =
                    DBConnection.getConnection();

            String query =
                    "INSERT INTO complaints(user_email, complaint_text, location, evidence_file) VALUES(?,?,?,?)";
            PreparedStatement pst =
                    con.prepareStatement(query);

            pst.setString(1, user);
            pst.setString(2, complaint);
            pst.setString(3, location);
            pst.setString(4, fileName);

            int rows =
                    pst.executeUpdate();

            if(rows > 0){

                response.getWriter().println(
                        "Complaint Submitted Successfully 🚨"
                );

            } else {

                response.getWriter().println(
                        "Complaint Failed"
                );
            }

        } catch (Exception e) {

            e.printStackTrace();

            response.getWriter().println(
                    "Error: " + e.getMessage()
            );
        }
    }
}