package org.example;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws IOException {

        HttpSession session =
                request.getSession(false);

        response.setContentType("text/plain");

        if(session != null &&
                session.getAttribute("user") != null){

            response.getWriter().print(
                    session.getAttribute("user")
            );

        } else {

            response.getWriter().print(
                    "Guest"
            );
        }
    }
}