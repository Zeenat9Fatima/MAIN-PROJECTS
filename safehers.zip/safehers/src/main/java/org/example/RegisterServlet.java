package org.example;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("RegisterServlet Running...");
        String fullname =
                request.getParameter("fullname");

        String email =
                request.getParameter("email");

        String emergency =
                request.getParameter("emergency");

        String password =
                request.getParameter("password");

        try {

            Connection con =
                    DBConnection.getConnection();
            String checkQuery =
                    "SELECT * FROM users WHERE email=?";

            PreparedStatement checkPst =
                    con.prepareStatement(checkQuery);

            checkPst.setString(1, email);

            ResultSet rs =
                    checkPst.executeQuery();

            if(rs.next()){

                response.getWriter().println(
                        "User already registered!"
                );

                return;
            }
            String query =
                    "INSERT INTO users(name,email,password,emergency_contact) VALUES(?,?,?,?)";
            PreparedStatement pst =
                    con.prepareStatement(query);

            pst.setString(1, fullname);
            pst.setString(2, email);
            pst.setString(3, password);
            pst.setString(4, emergency);

            int rows = pst.executeUpdate();

            if(rows > 0){

                HttpSession session =
                        request.getSession();

                session.setAttribute("email", email);
                session.setAttribute("user", fullname);
                

                response.sendRedirect("index.html");

            } else {

                response.getWriter().println("Registration Failed");

            }

        } catch (Exception e) {

            System.out.println("ERROR FOUND:");
            e.printStackTrace();

            response.getWriter().println(
                    "Error: " + e.getMessage()
            );
        }

    };

}

