const sosBtn = document.getElementById("sosBtn");

// =========================
// LIVE LOCATION
// =========================

let map;
let marker;

document.addEventListener("DOMContentLoaded", () => {

    if (!navigator.geolocation) {

        alert("Geolocation is not supported");

        return;
    }

    navigator.geolocation.getCurrentPosition(

        function(position) {

            const lat = position.coords.latitude;
            const lng = position.coords.longitude;

            // Update Text
            document.getElementById("latitude").innerText = lat;
            document.getElementById("longitude").innerText = lng;

            document.getElementById("heroLat").innerText = lat;
            document.getElementById("heroLng").innerText = lng;

            // Main Map
            map = L.map("map").setView([lat, lng], 15);

            L.tileLayer(
                "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                {
                    attribution: "© OpenStreetMap"
                }
            ).addTo(map);

            marker = L.marker([lat, lng])
                .addTo(map)
                .bindPopup("You are here")
                .openPopup();

            // Hero Map
            const heroMap =
                L.map("heroMap", {
                    zoomControl: false,
                    attributionControl: false
                }).setView([lat, lng], 14);

            L.tileLayer(
                "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            ).addTo(heroMap);

            L.marker([lat, lng]).addTo(heroMap);

        },

        function(error) {

            console.log(error);

            alert(
                "Location permission denied."
            );

        }

    );
    function goToLiveLocation() {

        document
            .getElementById("liveLocationSection")
            .scrollIntoView({
                behavior: "smooth"
            });

    }
});
if (sosBtn) {
    sosBtn.addEventListener("click", activateSOS);
}

async function activateSOS() {

    try {

        if (!navigator.geolocation) {
            alert("Geolocation not supported");
            return;
        }

        navigator.geolocation.getCurrentPosition(

            async function(position) {

                const lat =
                    position.coords.latitude;

                const lng =
                    position.coords.longitude;

                const locationLink =
                    "https://maps.google.com/?q="
                    + lat + "," + lng;

                startRecording(locationLink);

            },

            function() {
                alert("Location permission denied");
            }

        );

    }
    catch(err) {

        console.log(err);

    }
}

async function startRecording(locationLink) {

    try {

        const stream =
            await navigator.mediaDevices
                .getUserMedia({ audio: true });

        const mediaRecorder =
            new MediaRecorder(stream);

        const audioChunks = [];

        mediaRecorder.ondataavailable =
            event => {

                audioChunks.push(event.data);

            };

        mediaRecorder.onstop = function() {
            document.getElementById(
                "sosStatus"
            ).innerHTML =
                "✔ Audio Saved";

            document.getElementById(
                "recordingTimer"
            ).innerHTML =
                "Done";
            const audioBlob =
                new Blob(audioChunks,
                    {
                        type: "audio/webm"
                    });

            uploadSOS(
                locationLink,
                audioBlob
            );

            openWhatsApp(locationLink);
        };

        mediaRecorder.start();
        document.getElementById(
            "sosStatus"
        ).innerHTML =
            "🎤 Recording Audio...";

        let seconds = 15;

        document.getElementById(
            "recordingTimer"
        ).innerHTML =
            seconds;

        const timer =
            setInterval(() => {

                seconds--;

                document.getElementById(
                    "recordingTimer"
                ).innerHTML =
                    seconds;

                if(seconds <= 0){

                    clearInterval(timer);

                }

            },1000);
        console.log("Recording Started");

        setTimeout(() => {

            mediaRecorder.stop();

            console.log("Recording Stopped");

        }, 15000);

    }
    catch(error) {

        console.log(error);

        alert(
            "Microphone permission denied"
        );
    }
}

function uploadSOS(locationLink, audioBlob) {

    const formData =
        new FormData();

    formData.append(
        "location",
        locationLink
    );

    formData.append(
        "audio",
        audioBlob,
        "sos_audio.webm"
    );

    fetch("SOSServlet", {

        method: "POST",

        body: formData

    })
        .then(response => response.text())
        .then(data => {

            console.log(data);

        })
        .catch(error => {

            console.log(error);

        });
}

function openWhatsApp(locationLink) {

    const phone =
        "917275537772";

    const message =
        "🚨 EMERGENCY SOS ALERT\n\n" +
        "I need immediate help!\n\n" +
        "Location:\n" +
        locationLink;

    const url =
        "https://wa.me/"
        + phone
        + "?text="
        + encodeURIComponent(message);

    window.open(url, "_blank");
}